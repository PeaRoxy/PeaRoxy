﻿////////////////////////////////////////////////////////////////////////////////////////////////
All files in this folder are certificates created for displaying HTTP content through the HTTPS
protocol.
These files will be used when you receive an error from PeaRoxy in a HTTPS website or when you
try to open a HTTPS website through a HTTP only proxy protocol (PeaRoxyWeb, etc).
You can delete these files at any moment. We will re-create them when necessary.
////////////////////////////////////////////////////////////////////////////////////////////////